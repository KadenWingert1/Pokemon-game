This Program uses several functions to create a map of the board.
The function makeWalls() creates the outside borders, and uses 2 functions to create the paths
(one function for North/South, and one for East/West)
The values for each spot on the map are stored in a 2d array
A large function called terrain() also exists which fills the map with boulders, water, tall grass,
and short grasss. Additionally, a random amount of trees are placed throuout the map.
Functions to place a pokecenter and pokemart exist to place a P or a C on a random spot on the map, 
next to a path

