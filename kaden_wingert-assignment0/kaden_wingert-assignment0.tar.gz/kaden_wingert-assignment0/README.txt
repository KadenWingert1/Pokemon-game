This Program uses recursion to find every possible path for a knight to touch evert square
from every starting positionon a 5x5 chessboard.

My solution involves storing the path that the knight travels in a 2d array and printing the path
if the night successfully completes the tour.

A function named tryPath is exists to attempt every possible move by the knight and returns true if the knight took
a valid path. This is where the majorit yof the logic is

